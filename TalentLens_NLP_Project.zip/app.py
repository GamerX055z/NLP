from pathlib import Path

from flask import Flask, redirect, render_template, request, session, url_for

from nlp_project.recommender import RecruitmentNLPSystem


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DEFAULT_JOB = (
    "Looking for an NLP engineer with Python, machine learning, transformers, "
    "spaCy, and text classification experience."
)

app = Flask(__name__)
app.secret_key = "talentlens-dev-key"

system = RecruitmentNLPSystem(
    DATA_DIR / "role_profiles.json",
    DATA_DIR / "training_samples.json",
)


def current_user() -> dict | None:
    role = session.get("role")
    if not role:
        return None
    return {
        "role": role,
        "name": session.get("name", "Guest User"),
        "email": session.get("email", ""),
    }


@app.route("/", methods=["GET"])
def home():
    return render_template("home.html", project_summary=system.project_summary())


@app.route("/login/<user_role>", methods=["GET", "POST"])
def login(user_role: str):
    if user_role not in {"jobseeker", "recruiter"}:
        return redirect(url_for("home"))

    role_title = "Job Seeker" if user_role == "jobseeker" else "Recruiter"
    if request.method == "POST":
        session["role"] = user_role
        session["name"] = request.form.get("name", "").strip() or role_title
        session["email"] = request.form.get("email", "").strip()
        destination = "jobseeker_dashboard" if user_role == "jobseeker" else "recruiter_dashboard"
        return redirect(url_for(destination))

    return render_template("login.html", user_role=user_role, role_title=role_title)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/jobseeker", methods=["GET"])
def jobseeker_dashboard():
    user = current_user()
    if not user or user["role"] != "jobseeker":
        return redirect(url_for("login", user_role="jobseeker"))

    return render_template(
        "jobseeker.html",
        user=user,
        project_summary=system.project_summary(),
        default_resume=(DATA_DIR / "sample_resumes.txt").read_text(encoding="utf-8").split("---")[0].strip(),
    )


@app.route("/jobseeker/analyze", methods=["POST"])
def jobseeker_analyze():
    user = current_user()
    if not user or user["role"] != "jobseeker":
        return redirect(url_for("login", user_role="jobseeker"))

    resume_text = request.form.get("resume_text", "").strip()
    resume_analysis = system.analyze_resume(resume_text) if resume_text else None
    recommendation = resume_analysis["recommendations"] if resume_analysis else []
    keywords = resume_analysis["keywords"] if resume_analysis else []

    return render_template(
        "jobseeker.html",
        user=user,
        resume_text=resume_text,
        resume_analysis=resume_analysis,
        recommendation=recommendation,
        keywords=keywords,
        project_summary=system.project_summary(),
        default_resume=resume_text or (DATA_DIR / "sample_resumes.txt").read_text(encoding="utf-8").split("---")[0].strip(),
    )


@app.route("/recruiter", methods=["GET"])
def recruiter_dashboard():
    user = current_user()
    if not user or user["role"] != "recruiter":
        return redirect(url_for("login", user_role="recruiter"))

    return render_template(
        "recruiter.html",
        user=user,
        project_summary=system.project_summary(),
        default_job_description=DEFAULT_JOB,
        default_resumes=(DATA_DIR / "sample_resumes.txt").read_text(encoding="utf-8"),
    )


@app.route("/recruiter/analyze", methods=["POST"])
def recruiter_analyze():
    user = current_user()
    if not user or user["role"] != "recruiter":
        return redirect(url_for("login", user_role="recruiter"))

    job_description = request.form.get("job_description", "").strip()
    resume_batch = request.form.get("resume_batch", "").strip()
    ranking = system.rank_resumes(job_description, resume_batch) if job_description and resume_batch else []

    return render_template(
        "recruiter.html",
        user=user,
        ranking=ranking,
        job_description=job_description,
        resume_batch=resume_batch,
        project_summary=system.project_summary(),
        default_job_description=job_description or DEFAULT_JOB,
        default_resumes=resume_batch or (DATA_DIR / "sample_resumes.txt").read_text(encoding="utf-8"),
    )


if __name__ == "__main__":
    app.run(debug=True)
