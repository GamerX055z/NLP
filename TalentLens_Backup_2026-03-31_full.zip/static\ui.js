(function () {
    function autoResize(textarea) {
        textarea.style.height = "auto";
        textarea.style.height = `${Math.max(textarea.scrollHeight, 140)}px`;
    }

    function wireTextareas(scope) {
        scope.querySelectorAll("textarea").forEach((textarea) => {
            autoResize(textarea);
            textarea.addEventListener("input", () => autoResize(textarea));
        });
    }

    function wireDropzones(scope) {
        scope.querySelectorAll("[data-dropzone]").forEach((dropzone) => {
            const input = dropzone.querySelector('input[type="file"]');
            const label = dropzone.querySelector("[data-file-label]");
            if (!input || !label) {
                return;
            }

            const render = () => {
                const fileNames = Array.from(input.files || []).map((file) => file.name);
                label.textContent = fileNames.length
                    ? fileNames.join(", ")
                    : "Drop a PDF, DOCX, or TXT here, or click to browse";
                dropzone.classList.toggle("has-file", fileNames.length > 0);
            };

            ["dragenter", "dragover"].forEach((eventName) => {
                dropzone.addEventListener(eventName, (event) => {
                    event.preventDefault();
                    dropzone.classList.add("drag-active");
                });
            });

            ["dragleave", "drop"].forEach((eventName) => {
                dropzone.addEventListener(eventName, (event) => {
                    event.preventDefault();
                    if (eventName === "drop") {
                        if (event.dataTransfer?.files?.length) {
                            input.files = event.dataTransfer.files;
                            render();
                        }
                    }
                    dropzone.classList.remove("drag-active");
                });
            });

            input.addEventListener("change", render);
            render();
        });
    }

    function wireHistoryCards(scope) {
        scope.querySelectorAll("[data-history-card]").forEach((card) => {
            card.addEventListener("click", () => {
                card.classList.toggle("expanded");
            });
        });
    }

    function wireModeSwitches(scope) {
        scope.querySelectorAll("[data-mode-switch]").forEach((switcher) => {
            const card = switcher.closest(".candidate-entry") || scope;
            const buttons = switcher.querySelectorAll("[data-mode-target]");
            const panels = card.querySelectorAll("[data-mode-panel]");

            const activate = (targetMode) => {
                buttons.forEach((button) => {
                    button.classList.toggle("is-active", button.dataset.modeTarget === targetMode);
                });
                panels.forEach((panel) => {
                    panel.classList.toggle("is-visible", panel.dataset.modePanel === targetMode);
                });
            };

            buttons.forEach((button) => {
                button.addEventListener("click", () => activate(button.dataset.modeTarget));
            });

            const hasText = Array.from(card.querySelectorAll("textarea")).some(
                (textarea) => textarea.value.trim().length > 0
            );
            activate(hasText ? "paste" : "upload");
        });
    }

    function init(scope) {
        wireTextareas(scope);
        wireDropzones(scope);
        wireHistoryCards(scope);
        wireModeSwitches(scope);
    }

    window.TalentLensUI = { init };

    document.addEventListener("DOMContentLoaded", () => {
        init(document);
    });
})();
